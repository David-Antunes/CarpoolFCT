package dataStructures;

public class KeyIterator<K,V> implements Iterator<K> {

	
	Iterator<Entry<K,V>> it;
	

	public KeyIterator(Iterator<Entry<K,V>> it) {
		this.it = it;
	}
	
	
	@Override
	public boolean hasNext() {
		
		return it.hasNext();
	}
	
	
	@Override
	public K next() throws NoSuchElementException {
		
		return it.next().getKey();
	}
	
	
	@Override
	public void rewind() {
		it.rewind();
		
	}

}
