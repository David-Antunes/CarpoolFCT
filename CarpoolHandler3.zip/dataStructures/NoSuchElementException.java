/**
 * 
 */
package dataStructures;

/**
 * @author AED_19_20
 *
 */
public class NoSuchElementException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public NoSuchElementException( )
	{
	super();
	}
	public NoSuchElementException( String msg )
	{
	super(msg);
	}
}
