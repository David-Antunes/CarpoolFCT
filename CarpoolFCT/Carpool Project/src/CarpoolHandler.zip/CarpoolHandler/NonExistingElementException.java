/**
 * 
 */
package CarpoolHandler;

/**
 * @author Carolina
 *
 */
public class NonExistingElementException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public NonExistingElementException() {
		super();
	}


}
