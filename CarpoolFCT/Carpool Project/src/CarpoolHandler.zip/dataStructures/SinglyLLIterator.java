package dataStructures;

public class SinglyLLIterator<E> implements Iterator<E> {

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public E next() throws NoSuchElementException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void rewind() {
		// TODO Auto-generated method stub

	}

}
