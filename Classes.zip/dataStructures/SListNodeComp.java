/**
 * 
 */
package dataStructures;

/**
 * @author Carolina
 *
 */
public class SListNodeComp<E> implements Comparable<E> {

	/**
	 * 
	 */
	public SListNodeComp() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
