package CarpoolHandler;

public class NoRideException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoRideException() {
		super();
	}


}
