package CarpoolHandler;

public interface Date{
	
	String getDay();
	
	String getMonth();
	
	String getYear();
	
	String getFullDate();
	
	boolean isDateValid(String date);
}
