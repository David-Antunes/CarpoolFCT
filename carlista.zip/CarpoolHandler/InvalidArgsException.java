/**
 * 
 */
package CarpoolHandler;

/**
 * @author Carolina
 *
 */
public class InvalidArgsException extends Exception {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidArgsException() {
		super();
	}

	public InvalidArgsException(String msg) {
		super(msg);
	}


}
