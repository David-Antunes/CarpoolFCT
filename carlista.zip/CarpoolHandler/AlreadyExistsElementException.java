/**
 * 
 */
package CarpoolHandler;

/**
 * @author Carolina
 *
 */
public class AlreadyExistsElementException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public AlreadyExistsElementException() {
		super();
	}


}
