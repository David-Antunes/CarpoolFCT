package dataStructures;

public class EntryIterator<K,V> implements Iterator<Entry<K,V>> {

	ArrayIterator<Map<K,V>> table;
	Map<K,V> currTable;
	Iterator<Entry<K,V>> listIt;
	
	
	public EntryIterator( Map<K, V>[] itTable) {
		table = new ArrayIterator<>(itTable, itTable.length);
		
		currTable = table.next();
		while(currTable.isEmpty())
			currTable = table.next();
		
		listIt = currTable.iterator();
		
	}

	
	@Override
	public boolean hasNext() {
		if(listIt.hasNext())
			return true;
		boolean found = false;
		
		while(!found && table.hasNext() ) {
			
			currTable = table.next();
			if(!currTable.isEmpty()) {
				found = true;
			}
			
		}
		return found;
	}

	
	@Override
	public Entry<K, V> next() throws NoSuchElementException {
		
		
		if(listIt.hasNext())
			return listIt.next();
		
		listIt = currTable.iterator();
		return listIt.next();
		
	}

	
	@Override
	public void rewind() {
		table.rewind();
		currTable = table.next();
		while(currTable.isEmpty())
			currTable = table.next();
		
		listIt = currTable.iterator();
		
		
	}

}
