/**
 * 
 */
package CarpoolHandler;


import dataStructures.Iterator;
import dataStructures.NoSuchElementException;
import dataStructures.SortedMap;

/**
 * @author Carolina
 *
 */
public class RideIterator<K,V> implements Iterator<RideWrapper> {
	
	
	
	Iterator<SortedMap<String, Ride>> bigIt;
	Iterator<Ride> smallIt;

	
	public RideIterator( SortedMap<Date, SortedMap<String, Ride>>  map) {
		
		
		bigIt = map.values();
		smallIt = bigIt.next().values();
		
	}

	
	@Override
	public boolean hasNext() {
		
		
		return bigIt.hasNext() || smallIt.hasNext();
	}

	
	@Override
	public RideWrapper next() throws NoSuchElementException {
		
		if(!hasNext())
			throw new NoSuchElementException();
		
		if(smallIt.hasNext())
			return smallIt.next();
		
		
			smallIt = bigIt.next().values();
			return smallIt.next();
			
		
	}

	
	@Override
	public void rewind() {
		bigIt.rewind();
		smallIt = bigIt.next().values();
		
	}

}
